"""
app/crud.py

Database operations backing the license API: looking up a key, checking
it's still valid, enforcing the plan's device-seat limit, and recording
every activation attempt for audit/support purposes.

Note on datetimes: MySQL's DATETIME/TIMESTAMP columns are stored
timezone-naive here (no TIMESTAMP WITH TIME ZONE in MySQL), so every
comparison below uses naive datetime.utcnow() rather than
datetime.now(timezone.utc) — mixing the two raises TypeError. The
server's own clock is assumed to be UTC or NTP-synced; see DEPLOY.md.

Usage:
    from app import crud
    key = crud.get_active_license_key(db, "MVCE-7F3A-9K2Q-XPL4")
    device, reason = crud.register_device(db, key, fingerprint, hostname, os_name)
"""

from datetime import datetime
from typing import Optional, Tuple

from sqlalchemy.orm import Session

from app.models import ActivationEvent, Device, LicenseKey, Plan, Subscription


def get_license_key(db: Session, key_code: str) -> Optional[LicenseKey]:
    """
    get_license_key(db, key_code)
    Usage: raw lookup by the string the user typed in, no validity
    checks — callers that need "is this usable right now" should use
    get_active_license_key instead.
    """
    return db.query(LicenseKey).filter(LicenseKey.key_code == key_code).first()


def get_active_license_key(db: Session, key_code: str) -> Tuple[Optional[LicenseKey], Optional[str]]:
    """
    get_active_license_key(db, key_code)
    Usage: the check the /v1/activate route runs before doing anything
    else. Returns (license_key, None) if the key is usable, or
    (None, reason) — reason is a short machine-readable string suitable
    for logging and for the UI's error message ("not_found",
    "revoked", "expired", "subscription_inactive").
    """
    key = get_license_key(db, key_code)
    if key is None:
        return None, "not_found"
    if key.status == "revoked":
        return None, "revoked"
    if key.expires_at < datetime.utcnow():
        return None, "expired"
    if key.subscription.status not in ("active",):
        return None, "subscription_inactive"
    return key, None


def register_device(db: Session, key: LicenseKey, fingerprint: str, hostname: Optional[str], os_name: Optional[str]) -> Tuple[Optional[Device], Optional[str]]:
    """
    register_device(db, key, fingerprint, hostname, os_name)
    Usage: called after get_active_license_key succeeds. If this device
    fingerprint has already activated this key, just refreshes
    last_seen_at (so reinstalling on the same machine never costs a
    seat). Otherwise checks the plan's max_devices before adding a new
    row. Returns (device, None) on success or (None, "seat_limit_reached").
    """
    existing = db.query(Device).filter(Device.license_key_id == key.id, Device.fingerprint == fingerprint).first()
    if existing is not None:
        existing.last_seen_at = datetime.utcnow()
        existing.hostname = hostname or existing.hostname
        existing.os = os_name or existing.os
        db.commit()
        return existing, None

    plan: Plan = key.subscription.plan
    active_device_count = (
        db.query(Device).filter(Device.license_key_id == key.id, Device.is_active.is_(True)).count()
    )
    if active_device_count >= plan.max_devices:
        return None, "seat_limit_reached"

    device = Device(license_key_id=key.id, fingerprint=fingerprint, hostname=hostname, os=os_name)
    db.add(device)
    db.commit()
    db.refresh(device)
    return device, None


def log_event(db: Session, event_type: str, license_key_id: Optional[str] = None, device_id: Optional[str] = None, detail: Optional[str] = None, ip_address: Optional[str] = None) -> None:
    """
    log_event(db, event_type, license_key_id, device_id, detail, ip_address)
    Usage: call after every activate/heartbeat/deactivate/denied outcome
    so support can look up "what happened to this key" without digging
    through server logs. event_type is one of the activation_events
    CHECK constraint values.
    """
    db.add(
        ActivationEvent(
            event_type=event_type,
            license_key_id=license_key_id,
            device_id=device_id,
            detail=detail,
            ip_address=ip_address,
        )
    )
    db.commit()


def deactivate_device(db: Session, key: LicenseKey, fingerprint: str) -> bool:
    """
    deactivate_device(db, key, fingerprint)
    Usage: frees a seat when a user explicitly signs out of a device
    (e.g. before reinstalling Windows). Returns True if a matching
    device was found and deactivated, False otherwise.
    """
    device = db.query(Device).filter(Device.license_key_id == key.id, Device.fingerprint == fingerprint).first()
    if device is None:
        return False
    device.is_active = False
    db.commit()
    return True
